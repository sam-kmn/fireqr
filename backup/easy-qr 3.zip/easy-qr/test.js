
// const lastIndex = parseInt('1',10)
const lastIndex = Number('1')

console.log(lastIndex+1)