<template>
    <div class="login d-flex justify-content-center align-items-center">
        <form @submit.prevent="signIn" class="container col-12 col-sm-7 col-md-6 col-lg-4 col-xl-3 p-2 bg-light rounded shadow p-3">
            <!-- <div class="m-3 text-center">
                <h1>Login panel</h1>
            </div> -->
            <div class="mb-3">
                <input type="email" class="form-control" placeholder="Email" v-model="email">
                <div class="form-text">We'll never share your email with anyone else.</div>
            </div>
            <div class="mb-3">
                <input type="password" class="form-control" placeholder="Password" v-model="password">
                <div class="form-text">Your password should contain atleast 6 characters</div>
            </div>
            <div class="">
                <button type="submit" class="col-6 btn btn-primary ">Sing In</button>
                <router-link class="col-6 btn btn-light" to="/register">Create new accout</router-link> 
            </div>
        </form>
    </div>
</template>


<script>
import {useRouter} from 'vue-router'
import {useStore} from 'vuex'
import {ref, onMounted} from 'vue'
import firebase from 'firebase'

export default {
    setup() {
        
        const store = useStore()
        const router = useRouter()
        const email = ref('')
        const password = ref('')

        onMounted(()=>{
            if (store.getters.getIsUser) router.push('/dashboard')
        })

        function signIn(){
            firebase.auth().signInWithEmailAndPassword(email.value, password.value)
                .then(() => router.push('/dashboard'))
                .catch(err => alert(err.message))
        }

        return{
            email,
            password,
            signIn
        }
    },
}
</script>


<style lang="scss" scoped>

  .login{
    width: 100vw;
    // height: 100vh;
    height: calc(100vh - 56px);

    // background-image: url("../assets/pattern-blur.png");
    // background-size: contain;

    background-color: #cececf;
    opacity: 0.8;
    background-image:  linear-gradient(30deg, #8d91db 12%, transparent 12.5%, transparent 87%, #8d91db 87.5%, #8d91db), linear-gradient(150deg, #8d91db 12%, transparent 12.5%, transparent 87%, #8d91db 87.5%, #8d91db), linear-gradient(30deg, #8d91db 12%, transparent 12.5%, transparent 87%, #8d91db 87.5%, #8d91db), linear-gradient(150deg, #8d91db 12%, transparent 12.5%, transparent 87%, #8d91db 87.5%, #8d91db), linear-gradient(60deg, #8d91db77 25%, transparent 25.5%, transparent 75%, #8d91db77 75%, #8d91db77), linear-gradient(60deg, #8d91db77 25%, transparent 25.5%, transparent 75%, #8d91db77 75%, #8d91db77);
    background-size: 32px 56px;
    background-position: 0 0, 0 0, 16px 28px, 16px 28px, 0 0, 16px 28px;
  }
</style>