<template>
    <div class="container-fluid">
        <div class="row justify-content-center align-items-center">

            <!-- tools -->
            <div class="col-12 order-1 py-5 py-sm-5">
                <div class="row justify-content-center align-items-center">

                    <!-- accordion -->
                    <div class="col-12 order-2 p-0 col-sm-6 col-md-5 col-lg-4">
                        <div class="accordion" id="accordionExample">

                            <!-- 1 general -->
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" >
                                    <img src="../assets/pencil.svg" alt="">
                                    &ensp;General
                                </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"  data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    
                                    <!-- type select -->
                                    <select class="form-select" v-model="type_select">
                                        <option value="1">Text / URL</option>
                                        <option value="2">SMS</option>
                                    </select>

                                    <!-- text/url input -->
                                    <input type="text" class="form-control mt-3" placeholder="Enter your content" v-if="type_select==='1'">

                                    <!-- sms input -->
                                    <div v-if="type_select==='2'">
                                        <input type="text" class="form-control mt-3" placeholder="Phone number">
                                        <input type="text" class="form-control mt-3" placeholder="Your message">
                                    </div>



                                </div>
                                </div>
                            </div>

                            <!-- 2 Foreground -->
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" >
                                    <img src="../assets/palette.svg" alt="">
                                    &ensp;Foreground
                                </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse"  data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <!-- <strong>head</strong> par  <code>code</code> <br> -->
                                    
                                    <!-- red -->
                                    <label for="fgRange1" class="form-label">Red: {{fgRGB[0]}}</label>
                                    <input type="range" class="form-range" v-model="fg_rangeR" id="fgRange1" min="0" max="255">
                                    <!-- green -->
                                    <label for="fgRange2" class="form-label">Green: {{fgRGB[1]}}</label>
                                    <input type="range" class="form-range" v-model="fg_rangeG" id="fgRange2" min="0" max="255">
                                    <!-- blue -->
                                    <label for="fgRange3" class="form-label">Blue: {{fgRGB[2]}}</label>
                                    <input type="range" class="form-range" v-model="fg_rangeB" id="fgRange3" min="0" max="255">
                                </div>
                                </div>
                            </div>

                            <!-- 3 Background -->
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingThree">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" >
                                    <img src="../assets/paint-bucket.svg" alt="">
                                    &ensp;Background
                                </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse collapse"  data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <!-- <strong>head</strong> par  <code>code</code> <br> -->
                                    
                                    <!-- red -->
                                    <label for="fgRange1" class="form-label">Red: {{bgRGB[0]}}</label>
                                    <input type="range" class="form-range" v-model="bg_rangeR" id="fgRange1" min="0" max="255">
                                    <!-- green -->
                                    <label for="fgRange2" class="form-label">Green: {{bgRGB[1]}}</label>
                                    <input type="range" class="form-range" v-model="bg_rangeG" id="fgRange2" min="0" max="255">
                                    <!-- blue -->
                                    <label for="fgRange3" class="form-label">Blue: {{bgRGB[2]}}</label>
                                    <input type="range" class="form-range" v-model="bg_rangeB" id="fgRange3" min="0" max="255">
                                </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <!-- image & btn -->
                    <div class="col-12 order-1 text-center col-sm-4 mb-5 mb-sm-0">
                        <div class="col-12">
                            <img class="p-1" src="../assets/download.svg" id="tools-svg">
                        </div>
                        <div class="col-12">
                            <button class="btn btn-sm btn-outline-primary rounded-pill mt-3">Create</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- all items -->
            <div class="col-12 col-md-9 col-lg-8  order-2 border rounded shadow" id="allItems">
                <!-- item -->
                <div class="col my-4"
                v-for="item, idx in test" :key="idx">
                    <div class="row align-items-center">
                        <!-- img -->
                        <div class="col-1"><img class="img-thumbnail" src="../assets/download.png" alt=""></div>

                        <!-- item body -->
                        <div class="col-9">{{item}}</div>

                        <!-- edit btn -->
                        <div class="col-2">
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown">
                                    Edit
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#">Rename</a></li>
                                    <li><a class="dropdown-item" href="#">Delete</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>
    </div>
</template>

<script>

import {ref, computed} from 'vue'

// import '@simonwep/pickr/dist/themes/nano.min.css';      // 'nano' theme

// // Modern or es5 bundle (pay attention to the note below!)
// import Pickr from '@simonwep/pickr';
// import Pickr from '@simonwep/pickr/dist/pickr.es5.min';

export default {
    setup() {

        const type_select = ref('1')

        const fg_rangeR = ref('255')
        const fg_rangeG = ref('255')
        const fg_rangeB = ref('255')

        const bg_rangeR = ref('0')
        const bg_rangeG = ref('0')
        const bg_rangeB = ref('0')

        const fgRGB = computed(() => [
                computed(() => fg_rangeR.value).value,
                computed(() => fg_rangeG.value).value,
                computed(() => fg_rangeB.value).value, ])

        const bgRGB = computed(() => [
                computed(() => bg_rangeR.value).value,
                computed(() => bg_rangeG.value).value,
                computed(() => bg_rangeB.value).value, ])


        const test = [
            'Facebook fanpage link', 
            'Youtube example video',
            'Lorem ipsum',
            'Foobar xdd',
            'Wow this is starting to look good',
            'Testing 1',
            'Testing 2',
            ]
        
        return{
            test, type_select,
            fg_rangeR, fg_rangeG, fg_rangeB, fgRGB, 
            bg_rangeR, bg_rangeG, bg_rangeB, bgRGB, 
            
        }
    },
}
</script>

<style lang="scss">

// #allItems{
//     height: 20rem;
//     overflow-y: scroll;
// }
    // #app, html{
        // background: grey !important;
    // }


</style>